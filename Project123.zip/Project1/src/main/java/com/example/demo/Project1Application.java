package com.example.demo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Project1Application {

	public static void main(String[] args) throws IOException {
		
	   Properties prop=new Properties();
	  File f=new File("./application.properties");
	
		BufferedReader br= new BufferedReader(new FileReader(f));

	  prop.load(br);
	  System.out.println(prop.getProperty("FIELDALIAS-date"));
		try (Reader reader = new FileReader("C:\\Users\\ananth.reddy01\\Desktop\\input.json")) {

		ObjectMapper on = new ObjectMapper();

			Input i = on.readValue(reader, Input.class);
			
			List<String> fields = new ArrayList<String>();
			fields.add("date");
			fields.add("action");
			fields.add("category");
			fields.add("src_user_role");
			fields.add("src_user_id");
			fields.add("dest_name");
			fields.add("dest_bunit");
			fields.add("dest_ip");
			fields.add("dest_category");
			fields.add("file_name");
			fields.add("file_hash");
			fields.add("signature_id");
			fields.add("user");
			fields.add("user_bunit");
			fields.add("vendor_product");
			fields.add("product_version");
			
			on.writeValue(new File("C:\\Users\\ananth.reddy01\\Desktop\\output.json"), new Output(i,fields));
			

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}