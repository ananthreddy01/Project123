package com.example.demo;

import java.util.List;
import java.util.stream.Collectors;

public class Output {
	
	String date;
	String action;
	String category;
	String src_user_role;
	String src_user_id;
	String dest_name;
	Location dest_bunit;
	String dest_ip;
	String dest_category;
	List<String> file_name;
	List<String> file_hash;
	int signature_id;
	String user;
	String user_bunit;
	String vendor_product;
	String product_version;
	
	public Output(Input obj,List<String> fields) {
		super();
		if(fields.contains("date")) {
		
            this.date = obj.getEventtimestamp();
		}
		if(fields.contains("action")) {
			
		     this.action = obj.getThreat().getGeneral().getAction_triggered();
		}
		if(fields.contains("category")) {
		
			  this.category = obj.getThreat().getName();
		}
		if(fields.contains("src_user_id")) {
			
		      this.src_user_id = obj.getUser_info().getUser_email();
		}
		if(fields.contains("src_user_role")) {
	
               this.src_user_role = obj.getUser_info().getUser_role();
		}
		if(fields.contains("dest_name")) {
			
		     this.dest_name = obj.getDevice_info().getImei();
		}     
		if(fields.contains("dest_bunit")) {
			
		       this.dest_bunit = obj.getLocation();
		}
		if(fields.contains("dest_ip")) {
		
		       this.dest_ip = obj.getThreat().getGeneral().getDevice_ip();
		}
		if(fields.contains("dest_category")) {
			
		      this.dest_category = obj.getDevice_info().getModel();
		}
		if(fields.contains("file_name")) {
		
			   this.file_name = obj.getForensics().getDetection_files().stream().map(DetectionFiles::getFile_name).collect(Collectors.toList());
		}
		if(fields.contains("file_hash")) {
		
			     this.file_hash = obj.getForensics().getDetection_files().stream().map(DetectionFiles::getHash).collect(Collectors.toList());
		}
	    if(fields.contains("signature_id")) {
		
	    	this.signature_id = obj.getForensics().getType();
	    }
		if(fields.contains("user")) {
		
			this.user = obj.getUser_info().getEmployee_name();
		}
		if(fields.contains("user_bunit")) {
		
			this.user_bunit = obj.getUser_info().getUser_role();
		}
		if(fields.contains("vendor_product")) {
		 
			this.vendor_product = obj.getDevice_info().getApp();
		}
		if(fields.contains("product_version")) {
		
			this.product_version = obj.getDevice_info().getApp_version();
		}
		
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSrc_user_role() {
		return src_user_role;
	}

	public void setSrc_user_role(String src_user_role) {
		this.src_user_role = src_user_role;
	}

	public String getSrc_user_id() {
		return src_user_id;
	}

	public void setSrc_user_id(String src_user_id) {
		this.src_user_id = src_user_id;
	}

	public String getDest_name() {
		return dest_name;
	}

	public void setDest_name(String dest_name) {
		this.dest_name = dest_name;
	}

	public Location getDest_bunit() {
		return dest_bunit;
	}

	public void setDest_bunit(Location dest_bunit) {
		this.dest_bunit = dest_bunit;
	}

	public String getDest_ip() {
		return dest_ip;
	}

	public void setDest_ip(String dest_ip) {
		this.dest_ip = dest_ip;
	}

	public String getDest_category() {
		return dest_category;
	}

	public void setDest_category(String dest_category) {
		this.dest_category = dest_category;
	}

	public List<String> getFile_name() {
		return file_name;
	}

	public void setFile_name(List<String> file_name) {
		this.file_name = file_name;
	}

	public List<String> getFile_hash() {
		return file_hash;
	}

	public void setFile_hash(List<String> file_hash) {
		this.file_hash = file_hash;
	}

	public int getSignature_id() {
		return signature_id;
	}

	public void setSignature_id(int signature_id) {
		this.signature_id = signature_id;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getUser_bunit() {
		return user_bunit;
	}

	public void setUser_bunit(String user_bunit) {
		this.user_bunit = user_bunit;
	}

	public String getVendor_product() {
		return vendor_product;
	}

	public void setVendor_product(String vendor_product) {
		this.vendor_product = vendor_product;
	}

	public String getProduct_version() {
		return product_version;
	}

	public void setProduct_version(String product_version) {
		this.product_version = product_version;
	}

	@Override
	public String toString() {
		return "Output [date=" + date + ", action=" + action + ", category=" + category + ", src_user_role="
				+ src_user_role + ", src_user_id=" + src_user_id + ", dest_name=" + dest_name + ", dest_bunit="
				+ dest_bunit + ", dest_ip=" + dest_ip + ", dest_category=" + dest_category + ", file_name=" + file_name
				+ ", file_hash=" + file_hash + ", signature_id=" + signature_id + ", user=" + user + ", user_bunit="
				+ user_bunit + ", vendor_product=" + vendor_product + ", product_version=" + product_version + "]";
	}
	
	
	

}
