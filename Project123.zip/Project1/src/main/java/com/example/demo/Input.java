package com.example.demo;
import java.util.Arrays;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Input {
	String system_token;
	int severity;
	String event_id;
	Forensics forensics;
	boolean mitigated;
	Location location;
	String eventtimestamp;
	UserInfo user_info;
	DeviceOwner device_owner;
	DeviceInfo device_info;
	Threat threat;
	String account_id;
	String team_id;
	String team_name;
	
	
	
	@Override
	public String toString() {
		return "Input [system_token=" + system_token + ", severity=" + severity + ", event_id=" + event_id
				+ ", forensics=" + forensics + ", mitigated=" + mitigated + ", location=" + location
				+ ", eventtimestamp=" + eventtimestamp + ", user_info=" + user_info + ", device_owner=" + device_owner
				+ ", device_info=" + device_info + ", threat=" + threat + ", account_id=" + account_id + ", team_id="
				+ team_id + ", team_name=" + team_name + "]";
	}
	public Input() {
		super();
	}
	public String getSystem_token() {
		return system_token;
	}
	public void setSystem_token(String system_token) {
		this.system_token = system_token;
	}
	public int getSeverity() {
		return severity;
	}
	public void setSeverity(int severity) {
		this.severity = severity;
	}
	public String getEvent_id() {
		return event_id;
	}
	public void setEvent_id(String event_id) {
		this.event_id = event_id;
	}
	public Forensics getForensics() {
		return forensics;
	}
	public void setForensics(Forensics forensics) {
		this.forensics = forensics;
	}
	public boolean isMitigated() {
		return mitigated;
	}
	public void setMitigated(boolean mitigated) {
		this.mitigated = mitigated;
	}
	public Location getLocation() {
		return location;
	}
	public void setLocation(Location location) {
		this.location = location;
	}
	public String getEventtimestamp() {
		return eventtimestamp;
	}
	public void setEventtimestamp(String eventtimestamp) {
		this.eventtimestamp = eventtimestamp;
	}
	public UserInfo getUser_info() {
		return user_info;
	}
	public void setUser_info(UserInfo user_info) {
		this.user_info = user_info;
	}
	public DeviceOwner getDevice_owner() {
		return device_owner;
	}
	public void setDevice_owner(DeviceOwner device_owner) {
		this.device_owner = device_owner;
	}
	public DeviceInfo getDevice_info() {
		return device_info;
	}
	public void setDevice_info(DeviceInfo device_info) {
		this.device_info = device_info;
	}
	public Threat getThreat() {
		return threat;
	}
	public void setThreat(Threat threat) {
		this.threat = threat;
	}
	public String getAccount_id() {
		return account_id;
	}
	public void setAccount_id(String account_id) {
		this.account_id = account_id;
	}
	public String getTeam_id() {
		return team_id;
	}
	public void setTeam_id(String team_id) {
		this.team_id = team_id;
	}
	public String getTeam_name() {
		return team_name;
	}
	public void setTeam_name(String team_name) {
		this.team_name = team_name;
	}

	
	
}

@JsonIgnoreProperties(ignoreUnknown = true)
class Forensics {
	String severity;
	String[] process_list;
	int os;
	NetworkThreat network_threat;
	String threat_uuid;
	String network_subnet;
	Object host_attack;
	String forensics_app_version;
	int type;
//	File[] detection_file;
	List<DetectionFiles> detection_files;
	String forensics_ziap_version;
	List<Val> general;
//	Val[] general;
	String event_id;
	@JsonProperty("BSSID")
	String BSSID;
	String network_encryption;
	AttackTime attack_time;
	String[] responses;
	String forensics_os_version;
	String zdid;
	@JsonProperty("SSID")
	String SSID;
	
	
	
	@Override
	public String toString() {
		return "Forensics [severity=" + severity + ", process_list=" + Arrays.toString(process_list) + ", os=" + os
				+ ", network_threat=" + network_threat + ", threat_uid=" + threat_uuid + ", network_subnet="
				+ network_subnet + ", host_attack=" + host_attack + ", forensics_app_version=" + forensics_app_version
				+ ", type=" + type + ", detection_file=" + detection_files +"forensics_ziap_version"+forensics_ziap_version+ ", general=" + general
				+ ", event_id=" + event_id + ", BSSID=" + BSSID + ", network_encryption=" + network_encryption
				+ ", attack_time=" + attack_time + ", responses=" + Arrays.toString(responses)
				+ ", forensics_os_version=" + forensics_os_version + ", zdid=" + zdid + ", SSID=" + SSID + "]";
	}
	public String getSeverity() {
		return severity;
	}
	public void setSeverity(String severity) {
		this.severity = severity;
	}
	public String[] getProcess_list() {
		return process_list;
	}
	public void setProcess_list(String[] process_list) {
		this.process_list = process_list;
	}
	public int getOs() {
		return os;
	}
	public void setOs(int os) {
		this.os = os;
	}
	public NetworkThreat getNetwork_threat() {
		return network_threat;
	}
	public void setNetwork_threat(NetworkThreat network_threat) {
		this.network_threat = network_threat;
	}
	public String getThreat_uuid() {
		return threat_uuid;
	}
	public void setThreat_uuid(String threat_uuid) {
		this.threat_uuid = threat_uuid;
	}
	public String getForensics_ziap_version() {
		return forensics_ziap_version;
	}
	public void setForensics_ziap_version(String forensics_ziap_version) {
		this.forensics_ziap_version = forensics_ziap_version;
	}
	public String getNetwork_subnet() {
		return network_subnet;
	}
	public void setNetwork_subnet(String network_subnet) {
		this.network_subnet = network_subnet;
	}
	public Object getHost_attack() {
		return host_attack;
	}
	public void setHost_attack(Object host_attack) {
		this.host_attack = host_attack;
	}
	public String getForensics_app_version() {
		return forensics_app_version;
	}
	public void setForensics_app_version(String forensics_app_version) {
		this.forensics_app_version = forensics_app_version;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public List<DetectionFiles> getDetection_files() {
		return detection_files;
	}
	public void setDetection_files(List<DetectionFiles> detection_files) {
		this.detection_files = detection_files;
	}
	public List<Val> getGeneral() {
		return general;
	}
	public void setGeneral(List<Val> general) {
		this.general = general;
	}
	public String getEvent_id() {
		return event_id;
	}
	public void setEvent_id(String event_id) {
		this.event_id = event_id;
	}
	public String getBSSID() {
		return BSSID;
	}
	public void setBSSID(String BSSID) {
		this.BSSID = BSSID;
	}
	public String getNetwork_encryption() {
		return network_encryption;
	}
	public void setNetwork_encryption(String network_encryption) {
		this.network_encryption = network_encryption;
	}
	public AttackTime getAttack_time() {
		return attack_time;
	}
	public void setAttack_time(AttackTime attack_time) {
		this.attack_time = attack_time;
	}
	public String[] getResponses() {
		return responses;
	}
	public void setResponses(String[] responses) {
		this.responses = responses;
	}
	public String getForensics_os_version() {
		return forensics_os_version;
	}
	public void setForensics_os_version(String forensics_os_version) {
		this.forensics_os_version = forensics_os_version;
	}
	public String getZdid() {
		return zdid;
	}
	public void setZdid(String zdid) {
		this.zdid = zdid;
	}
	public String getSSID() {
		return SSID;
	}
	public void setSSID(String sSID) {
		SSID = sSID;
	}	
	
	
	
}

@JsonIgnoreProperties(ignoreUnknown = true)
class NetworkThreat{
	String process_list;
	String basestation;
	String gw_ip;
	String routing_table;
	@JsonProperty("interface")
	String interface_;
	String net_stat;
	
	
	@Override
	public String toString() {
		return "NetworkThreat [process_list=" + process_list + ", basestation=" + basestation + ", gw_ip=" + gw_ip
				+ ", routing_table=" + routing_table + ", _interface=" + interface_ + ", net_stat=" + net_stat + "]";
	}
	public String getProcess_list() {
		return process_list;
	}
	public void setProcess_list(String process_list) {
		this.process_list = process_list;
	}
	public String getBasestation() {
		return basestation;
	}
	public void setBasestation(String basestation) {
		this.basestation = basestation;
	}
	public String getGw_ip() {
		return gw_ip;
	}
	public void setGw_ip(String gw_ip) {
		this.gw_ip = gw_ip;
	}
	public String getRouting_table() {
		return routing_table;
	}
	public void setRouting_table(String routing_table) {
		this.routing_table = routing_table;
	}
	public String get_interface() {
		return interface_;
	}
	public void set_interface(String interface_) {
		this.interface_ = interface_;
	}
	public String getNet_stat() {
		return net_stat;
	}
	public void setNet_stat(String net_stat) {
		this.net_stat = net_stat;
	}
	
	
	
}

@JsonIgnoreProperties
class DetectionFiles{
	String file_name;
	String hash;
	public String getFile_name() {
		return file_name;
	}
	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}
	public String getHash() {
		return hash;
	}
	public void setHash(String hash) {
		this.hash = hash;
	}
	@Override
	public String toString() {
		return "File [file_name=" + file_name + ", hash=" + hash + "]";
	}
	
	
}

@JsonIgnoreProperties(ignoreUnknown = true)
class Val{
	String val;
	String name;
	public String getVal() {
		return val;
	}
	public void setVal(String val) {
		this.val = val;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Val [val=" + val + ", name=" + name + "]";
	}
	
}

@JsonIgnoreProperties(ignoreUnknown = true)
class AttackTime {
	@JsonProperty("$date")
	long $date;

	@Override
	public String toString() {
		return "AttackTime [date=" + $date + "]";
	}

	public long get$Date() {
		return $date;
	}

	public void set$Date(long date) {
		this.$date = date;
	}
	
}

class Location {
	Double gps_latitude;
	Double gps_longitude;
	Double location_accuracy;
	
	
	@Override
	public String toString() {
		return "Location [gps_latitude=" + gps_latitude + ", gps_longitude=" + gps_longitude + ", location_accuracy="
				+ location_accuracy + "]";
	}
	public Double getGps_latitude() {
		return gps_latitude;
	}
	public void setGps_latitude(Double gps_latitude) {
		this.gps_latitude = gps_latitude;
	}
	public Double getGps_longitude() {
		return gps_longitude;
	}
	public void setGps_longitude(Double gps_longitude) {
		this.gps_longitude = gps_longitude;
	}
	public Double getLocation_accuracy() {
		return location_accuracy;
	}
	public void setLocation_accuracy(Double location_accuracy) {
		this.location_accuracy = location_accuracy;
	}
	
}

class UserInfo {
	String employee_name;
	String user_id;
	String user_role;
	String user_email;
	String first_name;
	String middle_name;
	String last_name;
	
	
	@Override
	public String toString() {
		return "UserInfo [Employee name= " +employee_name +"User_id =" + user_id + ", user_role=" + user_role + ", user_email=" + user_email
				+ ", first_name=" + first_name + ", middle_name=" + middle_name + ", last_name=" + last_name + "]";
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_role() {
		return user_role;
	}
	public void setUser_role(String user_role) {
		this.user_role = user_role;
	}
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getMiddle_name() {
		return middle_name;
	}
	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	
}

class DeviceOwner {
	String id;
	String email;
	String firstName;
	String middleName;
	String lastName;
	
	
	@Override
	public String toString() {
		return "DeviceOwner [id=" + id + ", email=" + email + ", firstName=" + firstName + ", middleName=" + middleName
				+ ", lastName=" + lastName + "]";
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
}

class DeviceInfo{
	String device_time;
	String tag1;
	String tag2;
	String app;
	String operator;
	String imei;
	String zdid;
	String app_version;
	String zapp_instance_id;
	String os;
	boolean jailbroken;
	String os_version;
	String model;
	String device_id;
	String type;
	
	
	@Override
	public String toString() {
		return "DeviceInfo [device_time=" + device_time + ", tag1=" + tag1 + ", tag2=" + tag2 + ", app=" + app
				+ ", operator=" + operator + ", imei=" + imei + ", zdid=" + zdid + ", app_version=" + app_version
				+ ", zapp_instance_id=" + zapp_instance_id + ", os=" + os + ", jailbroken=" + jailbroken
				+ ", os_version=" + os_version + ", model=" + model + ", device_id=" + device_id + ", type=" + type
				+ "]";
	}
	public String getDevice_time() {
		return device_time;
	}
	public void setDevice_time(String device_time) {
		this.device_time = device_time;
	}
	public String getTag1() {
		return tag1;
	}
	public void setTag1(String tag1) {
		this.tag1 = tag1;
	}
	public String getTag2() {
		return tag2;
	}
	public void setTag2(String tag2) {
		this.tag2 = tag2;
	}
	public String getApp() {
		return app;
	}
	public void setApp(String app) {
		this.app = app;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public String getImei() {
		return imei;
	}
	public void setImei(String imei) {
		this.imei = imei;
	}
	public String getZdid() {
		return zdid;
	}
	public void setZdid(String zdid) {
		this.zdid = zdid;
	}
	public String getApp_version() {
		return app_version;
	}
	public void setApp_version(String app_version) {
		this.app_version = app_version;
	}
	public String getZapp_instance_id() {
		return zapp_instance_id;
	}
	public void setZapp_instance_id(String zapp_instance_id) {
		this.zapp_instance_id = zapp_instance_id;
	}
	public String getOs() {
		return os;
	}
	public void setOs(String os) {
		this.os = os;
	}
	public boolean isJailbroken() {
		return jailbroken;
	}
	public void setJailbroken(boolean jailbroken) {
		this.jailbroken = jailbroken;
	}
	public String getOs_version() {
		return os_version;
	}
	public void setOs_version(String os_version) {
		this.os_version = os_version;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getDevice_id() {
		return device_id;
	}
	public void setDevice_id(String device_id) {
		this.device_id = device_id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
}


//@JsonIgnoreProperties(ignoreUnknown = true)
class Threat {
	String name;
	String category;
	General general;
//	@JsonProperty("threat['threat_uuid']")
	String threat_uuid;
	String display_name;
	String[] mitre_tactics;
	String[] child_threat_uuids;
	
	
	@Override
	public String toString() {
		return "Threat [name=" + name + ", category=" + category + ", general=" + general + ", threat_uuid=" + threat_uuid
				+ ", display_name=" + display_name + ", mitre_tactics=" + Arrays.toString(mitre_tactics)
				+ ", child_threat_uuids=" + Arrays.toString(child_threat_uuids) + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public General getGeneral() {
		return general;
	}
	public void setGeneral(General general) {
		this.general = general;
	}
	public String getThreat_uuid() {
		return threat_uuid;
	}
	public void setThreat_uuid(String threat_uid) {
		this.threat_uuid = threat_uid;
	}
	public String getDisplay_name() {
		return display_name;
	}
	public void setDisplay_name(String display_name) {
		this.display_name = display_name;
	}
	public String[] getMitre_tactics() {
		return mitre_tactics;
	}
	public void setMitre_tactics(String[] mitre_tactics) {
		this.mitre_tactics = mitre_tactics;
	}
	public String[] getChild_threat_uuids() {
		return child_threat_uuids;
	}
	public void setChild_threat_uuids(String[] child_threat_uuids) {
		this.child_threat_uuids = child_threat_uuids;
	}
	
	
}

class General {
	String time_interval;
	String device_time;
	String external_ip;
	String threat_type;
	String device_ip;
	String imei;
	String network;
	String network_bssid;
	String gateway_ip;
	String gateway_mac;
	String external_network;
	String network_interface;
	String network_encryption;
	String subnet_mask;
	String action_triggered;
	String device_mac;
	String attacker_ip;
	String attacker_mac;
	String attacker_ssid;
	String attacker_bssid;
	String base_station;
	String certificate;
	String stagefright_vulnerability_report;
	String jailbreak_reasons;
	String process;
	String sideloaded_app_package;
	String sideloaded_app_name;
	String sideloaded_app_developer;
	String event;
	String file_name;
	String file_path;
	String file_hash;
	String suspected_url;
	String module;
	String profile_category;
	String profile_description;
	String profile_identifier;
	String profile_name;
	String profile_type;
	String profile_risk;
	String malware_list;
	String package_name;
	String installer_source;
	String malware_family;
	
	
	@Override
	public String toString() {
		return "General [time_interval=" + time_interval + ", device_time=" + device_time + ", external_ip="
				+ external_ip + ", threat_type=" + threat_type + ", device_ip=" + device_ip + ", imei=" + imei
				+ ", network=" + network + ", network_bssid=" + network_bssid + ", gateway_ip=" + gateway_ip
				+ ", gateway_mac=" + gateway_mac + ", external_network=" + external_network + ", network_interface="
				+ network_interface + ", network_encryption=" + network_encryption + ", subnet_mask=" + subnet_mask
				+ ", action_triggered=" + action_triggered + ", device_mac=" + device_mac + ", attacker_ip="
				+ attacker_ip + ", attacker_mac=" + attacker_mac + ", attacker_ssid=" + attacker_ssid
				+ ", attacker_bssid=" + attacker_bssid + ", base_station=" + base_station + ", certificate="
				+ certificate + ", stagefright_vulnerability_report=" + stagefright_vulnerability_report
				+ ", jailbreak_reasons=" + jailbreak_reasons + ", process=" + process + ", sideloaded_app_package="
				+ sideloaded_app_package + ", sideloaded_app_name=" + sideloaded_app_name
				+ ", sideloaded_app_developer=" + sideloaded_app_developer + ", event=" + event + ", file_name="
				+ file_name + ", file_path=" + file_path + ", file_hash=" + file_hash + ", suspected_url="
				+ suspected_url + ", module=" + module + ", profile_category=" + profile_category
				+ ", profile_description=" + profile_description + ", profile_identifier=" + profile_identifier
				+ ", profile_name=" + profile_name + ", profile_type=" + profile_type + ", profile_risk=" + profile_risk
				+ ", malware_list=" + malware_list + ", package_name=" + package_name + ", installer_source="
				+ installer_source + ", malware_family=" + malware_family + "]";
	}
	public String getTime_interval() {
		return time_interval;
	}
	public void setTime_interval(String time_interval) {
		this.time_interval = time_interval;
	}
	public String getDevice_time() {
		return device_time;
	}
	public void setDevice_time(String device_time) {
		this.device_time = device_time;
	}
	public String getExternal_ip() {
		return external_ip;
	}
	public void setExternal_ip(String external_ip) {
		this.external_ip = external_ip;
	}
	public String getThreat_type() {
		return threat_type;
	}
	public void setThreat_type(String threat_type) {
		this.threat_type = threat_type;
	}
	public String getDevice_ip() {
		return device_ip;
	}
	public void setDevice_ip(String device_ip) {
		this.device_ip = device_ip;
	}
	public String getImei() {
		return imei;
	}
	public void setImei(String imei) {
		this.imei = imei;
	}
	public String getNetwork() {
		return network;
	}
	public void setNetwork(String network) {
		this.network = network;
	}
	public String getNetwork_bssid() {
		return network_bssid;
	}
	public void setNetwork_bssid(String network_bssid) {
		this.network_bssid = network_bssid;
	}
	public String getGateway_ip() {
		return gateway_ip;
	}
	public void setGateway_ip(String gateway_ip) {
		this.gateway_ip = gateway_ip;
	}
	public String getGateway_mac() {
		return gateway_mac;
	}
	public void setGateway_mac(String gateway_mac) {
		this.gateway_mac = gateway_mac;
	}
	public String getExternal_network() {
		return external_network;
	}
	public void setExternal_network(String external_network) {
		this.external_network = external_network;
	}
	public String getNetwork_interface() {
		return network_interface;
	}
	public void setNetwork_interface(String network_interface) {
		this.network_interface = network_interface;
	}
	public String getNetwork_encryption() {
		return network_encryption;
	}
	public void setNetwork_encryption(String network_encryption) {
		this.network_encryption = network_encryption;
	}
	public String getSubnet_mask() {
		return subnet_mask;
	}
	public void setSubnet_mask(String subnet_mask) {
		this.subnet_mask = subnet_mask;
	}
	public String getAction_triggered() {
		return action_triggered;
	}
	public void setAction_triggered(String action_triggered) {
		this.action_triggered = action_triggered;
	}
	public String getDevice_mac() {
		return device_mac;
	}
	public void setDevice_mac(String device_mac) {
		this.device_mac = device_mac;
	}
	public String getAttacker_ip() {
		return attacker_ip;
	}
	public void setAttacker_ip(String attacker_ip) {
		this.attacker_ip = attacker_ip;
	}
	public String getAttacker_mac() {
		return attacker_mac;
	}
	public void setAttacker_mac(String attacker_mac) {
		this.attacker_mac = attacker_mac;
	}
	public String getAttacker_ssid() {
		return attacker_ssid;
	}
	public void setAttacker_ssid(String attacker_ssid) {
		this.attacker_ssid = attacker_ssid;
	}
	public String getAttacker_bssid() {
		return attacker_bssid;
	}
	public void setAttacker_bssid(String attacker_bssid) {
		this.attacker_bssid = attacker_bssid;
	}
	public String getBase_station() {
		return base_station;
	}
	public void setBase_station(String base_station) {
		this.base_station = base_station;
	}
	public String getCertificate() {
		return certificate;
	}
	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}
	public String getStagefright_vulnerability_report() {
		return stagefright_vulnerability_report;
	}
	public void setStagefright_vulnerability_report(String stagefright_vulnerability_report) {
		this.stagefright_vulnerability_report = stagefright_vulnerability_report;
	}
	public String getJailbreak_reasons() {
		return jailbreak_reasons;
	}
	public void setJailbreak_reasons(String jailbreak_reasons) {
		this.jailbreak_reasons = jailbreak_reasons;
	}
	public String getProcess() {
		return process;
	}
	public void setProcess(String process) {
		this.process = process;
	}
	public String getSideloaded_app_package() {
		return sideloaded_app_package;
	}
	public void setSideloaded_app_package(String sideloaded_app_package) {
		this.sideloaded_app_package = sideloaded_app_package;
	}
	public String getSideloaded_app_name() {
		return sideloaded_app_name;
	}
	public void setSideloaded_app_name(String sideloaded_app_name) {
		this.sideloaded_app_name = sideloaded_app_name;
	}
	public String getSideloaded_app_developer() {
		return sideloaded_app_developer;
	}
	public void setSideloaded_app_developer(String sideloaded_app_developer) {
		this.sideloaded_app_developer = sideloaded_app_developer;
	}
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	public String getFile_name() {
		return file_name;
	}
	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}
	public String getFile_path() {
		return file_path;
	}
	public void setFile_path(String file_path) {
		this.file_path = file_path;
	}
	public String getFile_hash() {
		return file_hash;
	}
	public void setFile_hash(String file_hash) {
		this.file_hash = file_hash;
	}
	public String getSuspected_url() {
		return suspected_url;
	}
	public void setSuspected_url(String suspected_url) {
		this.suspected_url = suspected_url;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProfile_category() {
		return profile_category;
	}
	public void setProfile_category(String profile_category) {
		this.profile_category = profile_category;
	}
	public String getProfile_description() {
		return profile_description;
	}
	public void setProfile_description(String profile_description) {
		this.profile_description = profile_description;
	}
	public String getProfile_identifier() {
		return profile_identifier;
	}
	public void setProfile_identifier(String profile_identifier) {
		this.profile_identifier = profile_identifier;
	}
	public String getProfile_name() {
		return profile_name;
	}
	public void setProfile_name(String profile_name) {
		this.profile_name = profile_name;
	}
	public String getProfile_type() {
		return profile_type;
	}
	public void setProfile_type(String profile_type) {
		this.profile_type = profile_type;
	}
	public String getProfile_risk() {
		return profile_risk;
	}
	public void setProfile_risk(String profile_risk) {
		this.profile_risk = profile_risk;
	}
	public String getMalware_list() {
		return malware_list;
	}
	public void setMalware_list(String malware_list) {
		this.malware_list = malware_list;
	}
	public String getPackage_name() {
		return package_name;
	}
	public void setPackage_name(String package_name) {
		this.package_name = package_name;
	}
	public String getInstaller_source() {
		return installer_source;
	}
	public void setInstaller_source(String installer_source) {
		this.installer_source = installer_source;
	}
	public String getMalware_family() {
		return malware_family;
	}
	public void setMalware_family(String malware_family) {
		this.malware_family = malware_family;
	}
	
	
	
}
